// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  firebaseConfig:{
    apiKey: "AIzaSyB9o5gWk0qwII5l34CZYS63B1PJSXPb7RQ",
    authDomain: "volunteacher-management-50e59.firebaseapp.com",
    databaseURL:"https://volunteacher-management-50e59-default-rtdb.firebaseio.com/",
    projectId: "volunteacher-management-50e59",
    storageBucket: "volunteacher-management-50e59.appspot.com",
    messagingSenderId: "909764721468",
    appId: "1:909764721468:web:31636a5c7a5d334e92fc39"
  },
};



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
 