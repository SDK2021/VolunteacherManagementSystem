import { Participant } from "./participant";

export class Activity {
    
activityId:number;
	
activityName:String;

description:string;
	
participants:Participant[];
	
events:Event[];

}
