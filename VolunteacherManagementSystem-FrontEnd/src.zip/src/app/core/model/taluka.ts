import { District } from "./district";
import { Village } from "./village";



export class Taluka {
    talukaId:number;
    talukaName:String;
    district:District;
    villages:Village[];

    
}
