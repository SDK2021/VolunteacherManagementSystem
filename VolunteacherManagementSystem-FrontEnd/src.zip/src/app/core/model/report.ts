import { User } from "./user";


export class Report {
	reportId: number;

	title: String;

	description: String;

	creationDate: string;

	craetedBy: User;

}
