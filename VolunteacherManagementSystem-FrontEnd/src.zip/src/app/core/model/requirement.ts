import { School } from "./school";

export class Requirement {
     requirementId:number;
	
	 requirement:String;
	
	schools:School[];

	
	
}
