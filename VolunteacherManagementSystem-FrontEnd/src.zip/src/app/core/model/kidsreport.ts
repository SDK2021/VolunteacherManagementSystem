import { Kid } from "./kid";
import { User } from "./user";

export class Kidsreport {
	kidreportId: number;

	kid: Kid;

	createdDate: string;

	createdBy: User;

	discipline: number;

	prayer: number;

	artCraft:number

	goshthi: number;

	abhivyakti: number;

	volunteaching: number;

	games: String;

	sports:number

	interestArea:string

	remarks: String;

	maths: number;

	gujarati: number;

	english: number;
}
