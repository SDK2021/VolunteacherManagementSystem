export class Usertype {

    typeId: number;

    type: String;


}

