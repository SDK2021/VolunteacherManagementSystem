import { KidsGroup } from "./kids-group";


export class Content {
     contentId:number;

	 contentData:String;

	 group:KidsGroup;
}
