

export class Applicantrequest {
    requestId:number;
	emailId:String;
    name:String;
	phoneNumber:String;	
    gender:number;
    status:number;
    requestDate:string;
	
	
}

