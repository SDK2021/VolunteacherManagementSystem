import { State } from "./state";


export class Country {
     countryId:number;

	 countryName:String;

	 states:State[];
}
