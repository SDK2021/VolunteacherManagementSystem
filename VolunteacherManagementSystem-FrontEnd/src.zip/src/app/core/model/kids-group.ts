


export class KidsGroup {
    groupId:number;
    groupName:String;
    criteria:String;    
}
