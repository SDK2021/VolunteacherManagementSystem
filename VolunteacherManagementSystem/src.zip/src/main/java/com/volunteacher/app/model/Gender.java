package com.volunteacher.app.model;

public class Gender {

	public static final int MALE=1;
	public static final int FEMALE=2;
}
